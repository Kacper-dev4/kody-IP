% Laboratorium Identyfikacji Proces�w
% r. akad. 2016/17
%
% Kod pomocniczy do �wiczenia 2: Parametryczne dynamiczne modele liniowe


clear
%close all


% ------- Dane o obiekcie i o modelu -------

% wczytaj sygna�y wej�ciowe i wyj�ciowe (oraz prawdziwe parametry obiektu,
% je�li s� znane):
load('pomiaryZnanyObiekt');
%load('...odpowiedniPlikPomiar�wZNieznanegoObiektu...');

% po��dana struktura modelu:
dAm = 2;  % stopie� wielomianu A w modelu
dBm = 2;  % stopie� wielomianu B w modelu
dCm = 0;  % stopie� wielomianu C w modelu
dm = 1;   % op�nienie w modelu

% --------------------- koniec danych podawanych przez u�ytkownika


% ------- Korelacja wzajemna wyj�cia obiektu i sterowania -------
% Wykre�lenie korelacji wzajemnej tych sygna��w pozwala zaobserwowa� 
% warto�� op�nienia d w obiekcie. Pierwsza znacz�ca warto�� korelacji
% (znacznie r�na od zera) pojawia si� na wykresie dopiero dla
% przesuni�cia r�wnego d.
% T� w�a�ciwo�� warto wykorzysta� do wybrania d w modelu, gdy pracujemy na
% zbiorze pomiar�w z nieznanego obiektu.

figure('name', 'Korelacja');
korelacjaWzajemna(y_id, u_id);


% ------- Identyfikacja modelu -------
% Identyfikuj model o zadanej strukturze i wypisz efekty w oknie polece�.

% Uwaga: funkcje ARX i ARMAX nie przyjmuj� bezpo�rednio stopni wielomian�w,
% lecz liczb� parametr�w w wielomianach, kt�re nale�y zidentyfikowa�.
% W wielomianie A znamy wyraz pocz�tkowy a_0=1, zatem trzeba zidentyfikowa�
% tylko wsp�czynniki a_1:a_dAm (razem: dAm sztuk). 
% Podobnie dla wielomianu C.
% W wielomianie B trzeba zidentyfikowa� tak�e wsp�czynnik b0, kt�ry mo�e
% by� dowolny, zatem nale�y obliczy� dBm+1 wsp�czynnik�w.

dane_ident = iddata(y_id, u_id, 1);
%model = arx(dane_ident, [dAm dBm+1 dm])  % identyfikuj model ARX
model = armax(dane_ident, [dAm dBm+1 dCm dm])  % identyfikuj model ARMAX

% dla ch�tnych: identyfikacja modelu Boxa-Jenkinsa (zobacz: help bj) lub
% output error (zobacz: help oe); 
% uwaga, to wymaga korekt w kodzie weryfikuj�cym model!
%............


% ------- Weryfikacja modelu -------

% por�wnaj dane weryfikacyjne (nie dane, kt�re s�u�y�y do identyfikacji!)
% i wyj�cie modelu:

% test symulacyjny i test jednokrokowej predykcji wyj�� - na wsp�lnym
% wykresie, by mo�na je �atwo por�wna� - wraz z obliczeniem MSE:
figure('name', 'Test symulacyjny i test predykcji');
[MSE_sym, MSE_pred] = testSymIPred(model, u_wer, y_wer);
display(MSE_sym);
display(MSE_pred);
    
% test bia�o�ci b��d�w predykcji:
figure('name', 'Test bia�o�ci');
testBialosci(model, u_wer, y_wer);

% test skracania zer i biegun�w:
figure('name', 'Test skracania');
testSkracania(model);

% dla ch�tnych: oblicz warto�ci kryteri�w informacyjnych (AIC, BIC)
%..........
