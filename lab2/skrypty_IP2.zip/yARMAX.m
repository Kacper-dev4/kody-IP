function [y, t] = yARMAX(d, A, B, C, u)

% [y, t] = yARMAX(d, A, B, C, u)
%
% Zwraca odpowied� Y stacjonarnego obiektu typu ARMAX na pobudzenie U: 
%             B(z^-1)        C(z^-1)
% y(i) = z^-d ------- u(i) + ------- e(i)
%             A(z^-1)        A(z^-1)
% oraz chwile pr�bkowania T.
% 
% U�ycie C=1 jest r�wnowa�ne symulacji obiektu typu ARX.


% liczba pr�bek sterowania i oczekiwana liczba pr�bek wyj�cia:
N = length(u);

% chwile pr�bkowania:
t = 0 : N-1;  % okres pr�bkowania: 1

% bia�y szum do modelowania zak��cenia - uwaga, nie wyst�puje jako fizyczny 
% sygna�, zatem jest niemierzalny, dlatego nie jest zwracany na zewn�trz 
% funkcji:
e = randn(N, 1);  % randn() zwraca warto�� losow� o rozk�adzie normalnym, nie myli� z rand()

% obiekt dynamiczny tworzy si� przez:
% obiekt = tf( licznik, mianownik, okres_pr�bkowania, [opcje] );
% tu potrzebny jest obiekt "o wielu wej�ciach" (u oraz e), st�d licznik
% i mianownik musz� by� podane jako macierze typu cell {} 
% (wi�cej informacji: help tf)
obiekt = tf({B C}, {A A}, 1, 'variable', 'z^-1', 'inputDelay', [d 0]);

% symuluj wyj�cie obiektu:
y = lsim(obiekt, [u e], t);
