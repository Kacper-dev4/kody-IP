function [MSE_sym, MSE_pred] = testSymIPred(model, u_wer, y_wer)

% [MSE_sym, MSE_pred] = testSymIPred(model, u_wer, y_wer)
%
% Wykonuje test symulacyjny i test jednokrokowej predykcji wyj�� dla danego
% MODELU i zestawu weryfikacyjnych danych pomiarowych z obiektu - 
% wej�ciowych U_WER i wyj�ciowych Y_WER. 
% Rysuje wygenerowane przebiegi na wsp�lnym wykresie w bie��cym oknie. 
% Dodatkowo zwraca b��d �redniokwadratowy (MSE) obliczony dla wyj�cia
% modelu wyznaczonego obiema metodami.


% test symulacyjny:

% mo�na go wykona� tak... :
%dane_wer = iddata(y_wer, u_wer, 1);
%compare( dane_wer, model )

% ... lub z u�yciem posiadanej funkcji do generowania wyj�cia obiektu ARMAX:
[ym_sym, t] = yARMAX(0, model.a, model.b, model.c, u_wer);  
    % je�li C==1, w efekcie zostanie zasymulowany model ARX;
    % je�li C!=1, zostanie zasymulowany model ARMAX;
    % uwaga: 
    % MODEL zwracany przez polecenia ARX i ARMAX przechowuje
    % op�nienie dyskretne d jako zerowe wsp�czynniki w wielomianie B,
    % dlatego nie nale�y powiela� op�nienia w powy�szym wywo�aniu 
    % funkcji, lecz wstawi� 0

    
% test jednokrokowej predykcji wyj��:
ym_pred = predict( model, [y_wer u_wer], 1 );
% UWAGA, w starszych wersjach MATLAB-a polecenie predict zwraca warto��
% jako cell - nale�y odkomentowa� poni�sz� linijk�, aby z cella uzyska�
% zwyk�y wektor:
%ym_pred = ym_pred{1};


% wykresy w bie��cym oknie:
plot(t, y_wer, 'k');  % dane "zmierzone"
hold all
plot(t, ym_sym, 'r:');  % wyniki testu symulacyjnego
plot(t, ym_pred, 'b:');  % wyniki testu 1-krokowej predykcji
title('Test symulacyjny i jednokrokowej predykcji wyj��', 'fontsize', 12);
xlabel('nr pr�bki');
ylabel('wyj�cie');
legend('obiekt', 'model - symulacja', 'model - predykcja');


% oblicz MSE dla obu rodzaj�w wyj�cia modelu:
MSE_sym  = obliczMSE(y_wer, ym_sym);
MSE_pred = obliczMSE(y_wer, ym_pred);
