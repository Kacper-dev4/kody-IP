% Laboratorium Identyfikacji Proces�w
% r. akad. 2016/17
%
% Kod pomocniczy do �wiczenia 2: Parametryczne dynamiczne modele liniowe


clear 
%close all


% ------- Wyb�r parametr�w obiektu -------
% Zasymulujemy rzeczywisty obiekt za pomoc� modelu ARMAX.
% W�wczas b�dzie mo�na �atwiej sprawdzi� poprawno�� identyfikacji, ni�
% gdyby�my u�yli sygna��w pomiarowych z faktycznego obiektu rzeczywistego.

d = 2;  % op�nienie dyskretne w obiekcie
A = [1 -0.5 -0.3 0.1];  % wiel. A; uwaga, pierwszy wsp�czynnik musi by� r�wny 1
B = [0.5 0.1];  % wiel. B; pierwszy wsp�czynnik - dowolny
% w wielomianie C pierwszy wsp�czynnik musi by� r�wny 1:
%C = 1;  % C==1 -> model ARX
C = [1 -0.7 0.3];  % C!=1 -> model ARMAX

N = 1000;  % liczba pr�bek, kt�r� chcemy uzyska� (sumaryczna dla danych 
    % do identyfikacji i do weryfikacji)

% --------------------- koniec danych podawanych przez u�ytkownika

% nale�y upewni� si�, �e wybrany obiekt jest stabilny oraz �e wielomian C
% ma pierwiastki wewn�trz okr�gu jednostkowego; mo�na zbada� tak�e 
% minimalnofazowo�� obiektu (czyli po�o�enie pierwiastk�w wielomianu B):
bieguny = roots(A);  % pierwiastki wielomianu A, poni�ej B i C
zeraB = roots(B);
zeraC = roots(C);

figure
subplot(211)
    zplane(zeraB(:), bieguny(:));  % (:) = zapewnij wektory kolumnowe
    title('Zera (o) i bieguny (x) toru sterowania w obiekcie', 'fontsize', 12);
    xlabel('Re(z)');
    ylabel('Im(z)');
subplot(212)
    zplane(zeraC(:), bieguny(:));  % bieguny toru zak��cenia s� takie same, jak toru sterowania
    title('Zera (o) i bieguny (x) toru zak��cenia w obiekcie', 'fontsize', 12);
    xlabel('Re(z)');
    ylabel('Im(z)');
% PS. zobacz: help zplane, aby przeczyta� wyja�nienie u�ycia wektor�w
% wierszowych i kolumnowych w poleceniu zplane


% ------- Generacja danych "pomiarowych" -------
% Symulacja zbierania pomiar�w z rzeczywistego obiektu.

% sygna� wej�ciowy:
u = randn(N, 1)*10;  % pobudzenie szumem (o wybranym odchyleniu stand.)
    % - du�a zmienno�� sygna�u pobudzaj�cego stwarza dobre warunki do 
    % prowadzenia identyfikacji

% odpowied� obiektu na takie pobudzenie:
y = yARMAX(d, A, B, C, u);

% podziel zebrane przebiegi na dwa zbiory - dane do identyfikacji oraz dane
% do weryfikacji modelu; mog� by� r�nej d�ugo�ci (zazwyczaj do
% identyfikacji u�ywamy d�u�szego fragmentu), mog� by� r�wne:
%     - dane do identyfikacji modelu:
u_id = u(1:end/2);
y_id = y(1:end/2);
%     - dane do weryfikacji modelu:
u_wer = u(end/2+1:end);
y_wer = y(end/2+1:end);


% ------- Zapis danych do pliku -------

% zapisz dane - parametry modelu i wygenerowane sygna�y - by p�niej 
% wykorzystywa� te same przebiegi sygna��w do identyfikacji wielu r�nych
% modeli:
save('pomiaryZnanyObiekt');
