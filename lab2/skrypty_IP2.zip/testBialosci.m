function [] = testBialosci(model, u_wer, y_wer)

% [] = testBialosci(model, u_wer, y_wer)
%
% Wykonuje test bia�o�ci b��d�w predykcji dla danego MODELU i zestawu
% weryfikacyjnych danych pomiarowych wej�cia i wyj�cia obiektu U_WER
% i Y_WER. 
% Przedstawia wyniki na wykresie w bie��cym oknie. 


% --- wersja rozbudowana funkcji: "co si� w�a�ciwie dzieje w metodzie?" ---


% wyznacz wyj�cie modelu dla predykcji 1-krokowej:
ym_pred = predict( model, [y_wer u_wer], 1 );
% UWAGA, w starszych wersjach MATLAB-a polecenie predict zwraca warto��
% jako cell - nale�y odkomentowa� poni�sz� linijk�, aby z cella uzyska�
% zwyk�y wektor:
%ym_pred = ym_pred{1};

% oblicz b��dy predykcji:
eps = y_wer - ym_pred;  % wyj�cie obiektu minus wyj�cie modelu (predykowane!)

% estymuj autokorelacj� b��d�w predykcji:
N = length(eps);
M = floor(N/10);  % przyjmuje si�, �e wykre�lanie autokorelacji
                  % liczonej z pr�by ma sens dla przesuni�� do +- N/10
[autokor, przesuniecia] = xcorr(eps, M, 'coeff');  
    % opcja 'coeff' w��cza normalizacj� R(0) = 1

% wykres w bie��cym oknie:

% uwaga 1:
% autokorelacja jest sekwencj� liczb dla dyskretnych przesuni��,
% dlatego nie nale�y jej rysowa� lini� ci�g��, lecz jako zbi�r
% dyskretnych punkt�w
% uwaga 2:
% mo�na te� rysowa� wykres tylko dla przesuni�� >=0, bo autokorelacja 
% jest symetryczna
stem(przesuniecia, autokor);  % autokorelacja
hold all
zakres = 3/sqrt(N);
plot( [xlim NaN xlim], [1 1 NaN -1 -1] * zakres, 'k');  % +-zakres, 
                                       % w kt�rym ma si� zmie�ci� autokor.
title('Test bia�o�ci b��d�w predykcji', 'fontsize', 12);
xlabel('przesuni�cie \tau');
ylabel('autokorelacja b�. pred. R_{\epsilon\epsilon}(\tau)');
legend('R_{\epsilon\epsilon}(\tau)', 'dopuszczalny zakres dla \tau\neq0');
legend('location', 'best');


% --- alternatywnie - wersja skr�cona funkcji: polecenie MATLAB-a resid ---
% (zobacz: help resid)
%
%N = length(u_wer);
%M = floor(N/10);
%dane_wer = iddata(y_wer, u_wer, 1);
%resid(model, dane_wer, 'corr', M);  % interesuje nas pierwszy wykres
