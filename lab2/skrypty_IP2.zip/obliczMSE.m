function mse = obliczMSE(y_ob, y_m)

% mse = obliczMSE(y_ob, y_m)
%
% Oblicza b��d �redniokwadratowy (Mean Squared Error, MSE) dla podanych
% wektor�w pr�bek wyj�cia obiektu Y_OB i wyj�cia modelu Y_M.


if ~isequal( size(y_ob), size(y_m) )
    error('Wyj�cia obiektu i modelu musz� mie� taki sam rozmiar.');
end

mse = mean( (y_ob-y_m).^2 );
