function [] = testSkracania(model)

% [] = testSkracania(model)
%
% Wykonuje test skracania zer i biegun�w dla danego MODELU, tzn. rysuje
% jego zera i bieguny na wsp�lnym wykresie na p�aszczy�nie z.
% Przedstawia wyniki w bie��cym oknie wykresu na dw�ch rysunkach 
% (subplotach) - dla toru sterowania i toru zak��cenia. 


bieguny = roots(model.a);

% "model" przechowuje op�nienie d jako d zerowych pocz�tkowych
% wsp�czynnik�w wielomianu B - trzeba te zera pomin��:
indeks = find( abs(model.b) > 1e-10 );  % znajd� indeks pierwszego elementu!=0
zeraB = roots( model.b(indeks:end) );

zeraC = roots(model.c);

% rysuj wykres w bie��cym oknie:
subplot(211)
zplane(zeraB(:), bieguny(:));
title('Zera (o) i bieguny (x) toru sterowania w modelu', 'fontsize', 12);
xlabel('Re(z)');
ylabel('Im(z)');

subplot(212)
zplane(zeraC(:), bieguny(:));
title('Zera (o) i bieguny (x) toru zak��cenia w modelu', 'fontsize', 12);
xlabel('Re(z)');
ylabel('Im(z)');
